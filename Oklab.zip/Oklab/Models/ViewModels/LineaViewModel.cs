﻿namespace CrudCoreOklab.Models.ViewModels
{
    public class LineaViewModel
    {

        public int? CantidadReservas { get; set; }

        public string Meses {  get; set; }

    }
}
