﻿namespace CrudCoreOklab.Models.ViewModels
{
    public class PieViewModel
    {

        public double Porcentaje { get; set; }

        public string Habitacion {get; set;}

    }
}
