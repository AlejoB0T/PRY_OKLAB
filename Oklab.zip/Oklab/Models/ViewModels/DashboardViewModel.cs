﻿namespace CrudCoreOklab.Models.ViewModels
{
    public class DashboardViewModel
    {

        public List<LineaViewModel> ReservasPorMes { get; set; }
        public List<PieViewModel> HabitacionFavorita { get; set; }

    }
}
