﻿// CODIGO JS HABITACIÓN O

const Modal__Open = document.getElementById('Modal__Open');
const Modal_O = document.getElementById('Modal_O');
const Modal__Close = document.getElementById('Modal__Botom_Close');

Modal__Open.addEventListener('click', () => {
    Modal_O.classList.add('show');
});

Modal__Botom_Close.addEventListener('click', () => {
    Modal_O.classList.remove('show');
});

// CODIGO JS HABITACIÓN K

const Modal__Open1 = document.getElementById('Modal__Open1');
const Modal_K = document.getElementById('Modal_K');
const Modal__Close1 = document.getElementById('Modal__Botom_Close1');

Modal__Open1.addEventListener('click', () => {
    Modal_K.classList.add('show');
});

Modal__Botom_Close1.addEventListener('click', () => {
    Modal_K.classList.remove('show');
});

// CODIGO JS HABITACIÓN L

const Modal__Open2 = document.getElementById('Modal__Open2');
const Modal_L = document.getElementById('Modal_L');
const Modal__Close2 = document.getElementById('Modal__Botom_Close2');

Modal__Open2.addEventListener('click', () => {
    Modal_L.classList.add('show');
});

Modal__Botom_Close2.addEventListener('click', () => {
    Modal_L.classList.remove('show');
});

// CODIGO JS HABITACIÓN A

const Modal__Open3 = document.getElementById('Modal__Open3');
const Modal_A = document.getElementById('Modal_A');
const Modal__Close3 = document.getElementById('Modal__Botom_Close3');

Modal__Open3.addEventListener('click', () => {
    Modal_A.classList.add('show');
});

Modal__Botom_Close3.addEventListener('click', () => {
    Modal_A.classList.remove('show');
});

// CODIGO JS HABITACIÓN B

const Modal__Open4 = document.getElementById('Modal__Open4');
const Modal_B = document.getElementById('Modal_B');
const Modal__Close4 = document.getElementById('Modal__Botom_Close4');

Modal__Open4.addEventListener('click', () => {
    Modal_B.classList.add('show');
});

Modal__Botom_Close4.addEventListener('click', () => {
    Modal_B.classList.remove('show');
});